AniFlix native Android app (Kotlin + Jetpack Compose)

BUILD (on a PC)
1. Install Android Studio (developer.android.com/studio).
2. File > Open > choose this folder (the one that contains settings.gradle). Click "Trust Project".
3. Wait for the Gradle sync. Click Install if it asks for Android SDK 34.
4. Build > Build Bundle(s) / APK(s) > Build APK(s), then click "locate".
   Or plug in a phone with USB debugging and press the green Run button.
   If you had an older version installed, uninstall it first (or just install over it).

WHERE THINGS ARE   (app/src/main/java/com/shohagh/aniflixapp/)
  Config.kt        Supabase address + key, and the website address used for embedded players
  AniApplication   Starts loading data early, image cache (fast covers), wakes up the web engine
  Data.kt          Kinds (Anime / Movie / Web Series), models, Supabase calls, phone cache, random order
  Prefs.kt         My List and "last watched" saved on the phone
  Downloads.kt     Offline downloads (Android DownloadManager, saved in the app's private folder)
  History.kt       Watch history (shown in Downloads > History)
  App.kt           Routes (every screen), page-slide animations, floating glass dock
  Screens.kt       Home, My List, See all, Downloads + History, Detail, Watch, Offline player,
                   widening search bar
  Ui.kt            Theme, glass look, press bounce, scroll reveal, dock, posters, buttons
  Player.kt        ExoPlayer for direct video links and downloads, WebView for embedded players

ADDING A FEATURE
  New screen:   add a Route in App.kt, a branch in AniApp(), and a @Composable in Screens.kt
  New section:  add an entry to the Kind enum in Data.kt (table name + episodes table)
  New field:    read it in toTitle() in Data.kt and add it to the Title class
  Dock tab:     add to dockRoutes and dockTabs in App.kt

NOTES
  - Only plain video files (.mp4 .webm .m4v .mkv) can be downloaded. Embedded players and .m3u8 streams cannot.
  - Faster video start: export mp4 files with "fast start" (ffmpeg -movflags +faststart).
  - Covers: keep each cover around 100-300 KB (about 600x900).

LOGO / ICON
  The launcher icon comes from app/src/main/res/mipmap-*/ic_launcher.png (old phones) and
  ic_launcher_foreground.png + the colour icon_red in values/colors.xml (new phones).

FULLSCREEN VIDEO
  setBars() in Player.kt hides the system bars and lets video draw behind the notch / camera hole.
