package com.shohagh.aniflixapp

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Every screen of the app. Add a new screen by adding a Route and a branch in AniApp. */
sealed interface Route {
    data object Home : Route
    data object Downloads : Route
    data object MyList : Route
    data class SeeAll(val kind: Kind) : Route
    data class Detail(val kind: Kind, val id: Long) : Route
    data class Watch(val kind: Kind, val id: Long, val epId: Long) : Route
    data class Offline(val id: String) : Route
}

private val dockRoutes: List<Route> = listOf(Route.Home, Route.Downloads, Route.MyList)
private val dockTabs = listOf(
    DockTab("Home", Icons.Default.Home),
    DockTab("Downloads", DownloadIcon),
    DockTab("My List", Icons.Default.Favorite)
)

@Composable
fun AniApp() {
    val stack = remember { mutableStateListOf<Route>(Route.Home) }
    var saved by remember { mutableStateOf(Prefs.saved()) }
    val homeData = remember { mutableStateMapOf<Kind, KindData>() }
    val homeList = rememberLazyListState()
    val scope = rememberCoroutineScope()
    // 0 forward (slide in from the right), 1 back, 2 fade, 3 tab to the right, 4 tab to the left
    var motion by remember { mutableIntStateOf(0) }
    val lastTab = remember { intArrayOf(0) }

    val cur = stack.last()
    val tabIndex = dockRoutes.indexOf(cur)
    if (tabIndex >= 0) lastTab[0] = tabIndex

    val nav: (Route) -> Unit = {
        motion = 0
        stack.add(it)
    }
    val back: () -> Unit = {
        if (stack.size > 1) {
            motion = 1
            stack.removeAt(stack.lastIndex)
        }
    }
    val onToggle: (String) -> Unit = { key ->
        Prefs.toggle(key)
        saved = Prefs.saved()
    }
    BackHandler(enabled = stack.size > 1) { back() }

    // keeps download progress fresh while the app is open
    LaunchedEffect(Unit) {
        while (true) {
            Downloads.refresh()
            delay(700)
        }
    }

    AppBackground {
        Box(Modifier.fillMaxSize()) {
            AnimatedContent(
                targetState = cur,
                transitionSpec = {
                    val player = targetState is Route.Watch || targetState is Route.Offline ||
                        initialState is Route.Watch || initialState is Route.Offline
                    when {
                        player -> fadeIn(tween(220)) togetherWith fadeOut(tween(160))
                        motion == 0 ->
                            (slideInHorizontally(animationSpec = tween(360, easing = FastOutSlowInEasing)) { it / 3 } + fadeIn(tween(360))) togetherWith
                                (slideOutHorizontally(animationSpec = tween(360, easing = FastOutSlowInEasing)) { -it / 5 } + fadeOut(tween(240)))
                        motion == 1 ->
                            (slideInHorizontally(animationSpec = tween(360, easing = FastOutSlowInEasing)) { -it / 4 } + fadeIn(tween(360))) togetherWith
                                (slideOutHorizontally(animationSpec = tween(360, easing = FastOutSlowInEasing)) { it / 3 } + fadeOut(tween(240)))
                        motion == 3 ->
                            (slideInHorizontally(animationSpec = tween(380, easing = FastOutSlowInEasing)) { it / 2 } + fadeIn(tween(320))) togetherWith
                                (slideOutHorizontally(animationSpec = tween(380, easing = FastOutSlowInEasing)) { -it / 3 } + fadeOut(tween(220)))
                        motion == 4 ->
                            (slideInHorizontally(animationSpec = tween(380, easing = FastOutSlowInEasing)) { -it / 2 } + fadeIn(tween(320))) togetherWith
                                (slideOutHorizontally(animationSpec = tween(380, easing = FastOutSlowInEasing)) { it / 3 } + fadeOut(tween(220)))
                        else -> fadeIn(tween(300)) togetherWith fadeOut(tween(200))
                    }
                },
                label = "screen"
            ) { r ->
                when (r) {
                    is Route.Home -> SearchScaffold("AniFlix", nav) { HomeScreen(homeData, homeList, nav) }
                    is Route.Downloads -> DownloadsScreen(nav)
                    is Route.MyList -> SearchScaffold("My List", nav) { MyListScreen(saved, nav) }
                    is Route.SeeAll -> SeeAllScreen(r.kind, back, nav)
                    is Route.Detail -> DetailScreen(r.kind, r.id, saved, onToggle, back, nav)
                    is Route.Watch -> WatchScreen(r.kind, r.id, r.epId, back, nav)
                    is Route.Offline -> OfflineScreen(r.id, back)
                }
            }

            AnimatedVisibility(
                visible = tabIndex >= 0,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(tween(380, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300)),
                exit = slideOutVertically(tween(260)) { it } + fadeOut(tween(200))
            ) {
                GlassDock(selected = lastTab[0], tabs = dockTabs) { i ->
                    val target = dockRoutes[i]
                    if (target != cur) {
                        motion = if (i > tabIndex) 3 else 4
                        stack.clear()
                        stack.add(target)
                    } else if (target == Route.Home) {
                        scope.launch { homeList.animateScrollToItem(0) }
                    }
                }
            }
        }
    }
}
