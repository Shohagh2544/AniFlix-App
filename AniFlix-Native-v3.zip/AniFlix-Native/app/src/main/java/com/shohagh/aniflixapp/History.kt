package com.shohagh.aniflixapp

import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(
    val kind: Kind,
    val titleId: Long,
    val titleName: String,
    val cover: String?,
    val epId: Long,
    val epNumber: Int?,
    val epName: String?,
    val time: Long
) {
    val id: String get() = "${kind.name}:$titleId:$epId"
    val titleKey: String get() = "${kind.name}:$titleId"
    val label: String
        get() = if (kind == Kind.MOVIE) "Movie" else "Episode ${epNumber ?: ""}".trim()
}

fun timeAgo(ms: Long): String {
    val m = (System.currentTimeMillis() - ms) / 60000
    return when {
        m < 1 -> "just now"
        m < 60 -> "$m min ago"
        m < 1440 -> "${m / 60} h ago"
        m < 43200 -> "${m / 1440} d ago"
        else -> "a while ago"
    }
}

/** What you watched, newest first. Saved on the phone (up to 100 entries). */
object History {
    val items = mutableStateListOf<HistoryItem>()

    fun load() {
        items.clear()
        val raw = Prefs.getRaw("history") ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val kind = Kind.entries.firstOrNull { it.name == o.getString("kind") } ?: continue
                items.add(
                    HistoryItem(
                        kind = kind,
                        titleId = o.getLong("titleId"),
                        titleName = o.getString("titleName"),
                        cover = if (o.isNull("cover")) null else o.getString("cover"),
                        epId = o.getLong("epId"),
                        epNumber = if (o.isNull("epNumber")) null else o.getInt("epNumber"),
                        epName = if (o.isNull("epName")) null else o.getString("epName"),
                        time = o.getLong("time")
                    )
                )
            }
        } catch (e: Exception) {
            items.clear()
        }
    }

    private fun save() {
        val arr = JSONArray()
        for (h in items) {
            val o = JSONObject()
            o.put("kind", h.kind.name)
            o.put("titleId", h.titleId)
            o.put("titleName", h.titleName)
            o.put("cover", h.cover ?: JSONObject.NULL)
            o.put("epId", h.epId)
            o.put("epNumber", h.epNumber ?: JSONObject.NULL)
            o.put("epName", h.epName ?: JSONObject.NULL)
            o.put("time", h.time)
            arr.put(o)
        }
        Prefs.putRaw("history", arr.toString())
    }

    private fun push(item: HistoryItem) {
        items.removeAll { it.id == item.id }
        items.add(0, item)
        while (items.size > 100) items.removeAt(items.lastIndex)
        save()
    }

    /** Called when a video starts. [ep] is null for movies. */
    fun add(t: Title, ep: Episode?) {
        push(
            HistoryItem(t.kind, t.id, t.name, t.cover, ep?.id ?: 0L, ep?.number, ep?.name, System.currentTimeMillis())
        )
    }

    /** Called when a downloaded video is played offline. */
    fun addDownload(r: DlRecord) {
        val parts = r.titleKey.split(":")
        val kind = Kind.entries.firstOrNull { it.name == parts.getOrNull(0) } ?: return
        val tid = parts.getOrNull(1)?.toLongOrNull() ?: return
        push(HistoryItem(kind, tid, r.titleName, r.cover, r.epId, r.epNumber, r.epName, System.currentTimeMillis()))
    }

    fun remove(h: HistoryItem) {
        items.remove(h)
        save()
    }

    fun clear() {
        items.clear()
        save()
    }
}
