package com.shohagh.aniflixapp

import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import coil.imageLoader
import coil.request.CachePolicy
import coil.request.ImageRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** The three kinds of content. Each one maps to its own Supabase table(s). */
enum class Kind(val label: String, val plural: String, val table: String, val epTable: String?) {
    ANIME("Anime", "Anime", "series", "episodes"),
    MOVIE("Movie", "Movies", "movies", null),
    WEB("Web Series", "Web Series", "web_series", "web_episodes")
}

data class Title(
    val kind: Kind,
    val id: Long,
    val name: String,
    val description: String,
    val cover: String?,
    val year: Int?,
    val rating: Double?,
    val genre: String?,
    val videoUrl: String?
) {
    val key: String get() = "${kind.name}:$id"
}

data class Episode(val id: Long, val number: Int?, val name: String?, val videoUrl: String?)

class KindData(val items: List<Title>, val error: String?)

private fun JSONObject.str(k: String): String? =
    if (isNull(k)) null else optString(k, "").trim().takeIf { it.isNotEmpty() }

private fun JSONObject.intOrNull(k: String): Int? = if (isNull(k)) null else optInt(k)

private fun JSONObject.dblOrNull(k: String): Double? =
    if (isNull(k)) null else optDouble(k).takeIf { !it.isNaN() }

/**
 * Talks to Supabase (REST) and keeps everything in memory.
 * The last answer is also saved on the phone, so the next launch shows content instantly
 * while fresh data is fetched in the background. Lists are shuffled once per app launch.
 */
object Repo {
    private val http = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val cache = ConcurrentHashMap<Kind, List<Title>>()
    private val epCache = ConcurrentHashMap<String, List<Episode>>()
    private var appCtx: Context? = null

    /** Goes up by one when fresh data from the server replaced what was shown. */
    val updates = mutableIntStateOf(0)

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
    }

    private fun getRaw(path: String): String {
        val req = Request.Builder()
            .url("${Config.SUPABASE_URL}/rest/v1/$path")
            .header("apikey", Config.SUPABASE_KEY)
            .header("Authorization", "Bearer ${Config.SUPABASE_KEY}")
            .build()
        return http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}: ${body.take(160)}")
            body
        }
    }

    private fun toTitle(kind: Kind, o: JSONObject): Title = Title(
        kind = kind,
        id = o.getLong("id"),
        name = o.str("title") ?: "Untitled",
        description = o.str("description") ?: "",
        cover = o.str("cover_url"),
        year = o.intOrNull("year"),
        rating = o.dblOrNull("rating"),
        genre = o.str("genre"),
        videoUrl = o.str("video_url")
    )

    private fun parseTitles(kind: Kind, raw: String): List<Title> {
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { toTitle(kind, arr.getJSONObject(it)) }
    }

    private fun parseEpisodes(raw: String): List<Episode> {
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val dm = o.str("dailymotion_id")
            Episode(
                id = o.getLong("id"),
                number = o.intOrNull("episode_number"),
                name = o.str("title"),
                videoUrl = o.str("video_url") ?: dm?.let { "https://www.dailymotion.com/embed/video/$it" }
            )
        }
    }

    /** Downloads the first covers in the background so they are ready when the lists are drawn. */
    private fun prefetch(list: List<Title>) {
        val c = appCtx ?: return
        for (t in list.take(30)) {
            val u = t.cover ?: continue
            c.imageLoader.enqueue(
                ImageRequest.Builder(c)
                    .data(u)
                    .size(360, 540)
                    .memoryCachePolicy(CachePolicy.DISABLED)
                    .build()
            )
        }
    }

    private fun diskKey(kind: Kind) = "cache_${kind.name}"

    suspend fun titles(kind: Kind): List<Title> {
        cache[kind]?.let { return it }
        val disk = Prefs.getRaw(diskKey(kind))?.let { raw ->
            try {
                parseTitles(kind, raw)
            } catch (e: Exception) {
                null
            }
        }
        if (disk != null) {
            val list = disk.shuffled()
            cache[kind] = list
            prefetch(list)
            scope.launch { refresh(kind) }
            return list
        }
        val raw = withContext(Dispatchers.IO) { getRaw("${kind.table}?select=*&order=id.desc") }
        val list = parseTitles(kind, raw).shuffled()
        Prefs.putRaw(diskKey(kind), raw)
        cache[kind] = list
        prefetch(list)
        return list
    }

    private suspend fun refresh(kind: Kind) {
        try {
            val raw = getRaw("${kind.table}?select=*&order=id.desc")
            if (raw == Prefs.getRaw(diskKey(kind))) return
            val fresh = parseTitles(kind, raw)
            Prefs.putRaw(diskKey(kind), raw)
            val order = (cache[kind] ?: emptyList()).withIndex().associate { it.value.id to it.index }
            val merged = fresh.sortedBy { order[it.id] ?: -1 }
            cache[kind] = merged
            prefetch(merged)
            withContext(Dispatchers.Main) { updates.intValue = updates.intValue + 1 }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
        }
    }

    suspend fun loadKind(kind: Kind): KindData = try {
        KindData(titles(kind), null)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        KindData(emptyList(), e.message ?: "error")
    }

    suspend fun all(): List<Title> = coroutineScope {
        Kind.entries.map { k -> async { loadKind(k).items } }.awaitAll().flatten()
    }

    suspend fun find(kind: Kind, id: Long): Title? = titles(kind).firstOrNull { it.id == id }

    suspend fun episodes(t: Title): List<Episode> {
        val table = t.kind.epTable ?: return emptyList()
        epCache[t.key]?.let { return it }
        val dk = "ep_${t.key}"
        val path = "$table?select=*&series_id=eq.${t.id}&order=episode_number.asc"
        val disk = Prefs.getRaw(dk)?.let { raw ->
            try {
                parseEpisodes(raw)
            } catch (e: Exception) {
                null
            }
        }
        if (disk != null) {
            epCache[t.key] = disk
            scope.launch {
                try {
                    val raw = getRaw(path)
                    if (raw != Prefs.getRaw(dk)) {
                        Prefs.putRaw(dk, raw)
                        epCache[t.key] = parseEpisodes(raw)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                }
            }
            return disk
        }
        val raw = withContext(Dispatchers.IO) { getRaw(path) }
        val list = parseEpisodes(raw)
        Prefs.putRaw(dk, raw)
        epCache[t.key] = list
        return list
    }
}
