package com.shohagh.aniflixapp

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** state: 0 waiting, 1 downloading, 2 paused, 3 failed, 4 finished */
data class DlRecord(
    val id: String,
    val titleKey: String,
    val titleName: String,
    val cover: String?,
    val kindLabel: String,
    val epId: Long,
    val epNumber: Int?,
    val epName: String?,
    val fileName: String,
    val dmId: Long,
    val done: Boolean,
    val progress: Float,
    val bytes: Long,
    val state: Int
) {
    val label: String
        get() = if (epId == 0L) "Movie" else "Episode ${epNumber ?: ""}".trim()
}

private val dlRegex = Regex("""\.(mp4|webm|m4v|mkv)(\?|$)""", RegexOption.IGNORE_CASE)

/** Only plain video files can be saved. Embedded players and .m3u8 streams cannot. */
fun canDownload(url: String?): Boolean = url != null && dlRegex.containsMatchIn(url)

fun fmtSize(bytes: Long): String {
    if (bytes <= 0L) return "0 MB"
    val mb = bytes / 1048576.0
    return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024) else String.format(Locale.US, "%.0f MB", mb)
}

/**
 * Offline downloads. Files are saved with Android's DownloadManager into the app's own folder
 * (not shown in the gallery, removed if the app is uninstalled) and played back inside the app.
 */
object Downloads {
    val items = mutableStateListOf<DlRecord>()
    private var appCtx: Context? = null

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        load()
    }

    private fun dm(): DownloadManager = appCtx!!.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    private fun folder(): File? = appCtx?.getExternalFilesDir("downloads")

    fun file(r: DlRecord): File? = folder()?.let { File(it, r.fileName) }

    /** file:// address of a finished download, for the player. */
    fun uri(r: DlRecord): String? = file(r)?.takeIf { it.exists() }?.let { Uri.fromFile(it).toString() }

    fun has(titleKey: String, epId: Long): DlRecord? = items.firstOrNull { it.id == "$titleKey#$epId" }

    private class Job(val epId: Long, val number: Int?, val name: String?, val url: String)

    /** Queues a movie (eps == null) or the chosen episodes. Returns how many downloads were started. */
    fun enqueue(t: Title, eps: List<Episode>?): Int {
        val c = appCtx ?: return 0
        val dir = folder() ?: return 0
        dir.mkdirs()
        val jobs = if (eps == null) {
            listOfNotNull(t.videoUrl?.let { Job(0L, null, null, it) })
        } else {
            eps.mapNotNull { e -> e.videoUrl?.let { Job(e.id, e.number, e.name, it) } }
        }
        var started = 0
        for (j in jobs) {
            val id = "${t.key}#${j.epId}"
            if (items.any { it.id == id } || !canDownload(j.url)) continue
            val ext = dlRegex.find(j.url)?.groupValues?.get(1)?.lowercase() ?: "mp4"
            val fileName = "${t.kind.name.lowercase()}_${t.id}_${j.epId}.$ext"
            File(dir, fileName).delete()
            val label = if (j.epId == 0L) t.name else "${t.name} - Episode ${j.number ?: ""}".trim()
            val req = DownloadManager.Request(Uri.parse(j.url))
                .setTitle(label)
                .setDescription("AniFlix")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .addRequestHeader("Referer", Config.SITE)
                .setDestinationInExternalFilesDir(c, "downloads", fileName)
            val dmId = try {
                dm().enqueue(req)
            } catch (e: Exception) {
                -1L
            }
            if (dmId < 0) continue
            items.add(
                DlRecord(
                    id = id, titleKey = t.key, titleName = t.name, cover = t.cover, kindLabel = t.kind.label,
                    epId = j.epId, epNumber = j.number, epName = j.name, fileName = fileName, dmId = dmId,
                    done = false, progress = 0f, bytes = 0L, state = 0
                )
            )
            started++
        }
        if (started > 0) save()
        return started
    }

    fun remove(r: DlRecord) {
        if (!r.done) {
            try {
                dm().remove(r.dmId)
            } catch (e: Exception) {
            }
        }
        file(r)?.delete()
        items.remove(r)
        save()
    }

    /** Call regularly while the app is open: reads progress from the system and updates the list. */
    fun refresh() {
        val active = items.filter { !it.done && it.state != 3 }
        if (active.isEmpty()) return
        val ids = active.map { it.dmId }.toLongArray()
        val seen = HashSet<Long>()
        var changed = false
        val cursor = dm().query(DownloadManager.Query().setFilterById(*ids))
        cursor?.use { c ->
            while (c.moveToNext()) {
                val dmId = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID))
                val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val sofar = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                seen.add(dmId)
                val idx = items.indexOfFirst { it.dmId == dmId }
                if (idx < 0) continue
                val old = items[idx]
                val updated = when (st) {
                    DownloadManager.STATUS_SUCCESSFUL -> old.copy(
                        done = true, progress = 1f, state = 4,
                        bytes = file(old)?.length() ?: total
                    )
                    DownloadManager.STATUS_FAILED -> old.copy(state = 3)
                    DownloadManager.STATUS_PAUSED -> old.copy(state = 2)
                    DownloadManager.STATUS_PENDING -> old.copy(state = 0)
                    else -> old.copy(
                        state = 1,
                        progress = if (total > 0) (sofar.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f,
                        bytes = sofar
                    )
                }
                if (updated != old) {
                    items[idx] = updated
                    if (updated.state != old.state) changed = true
                }
            }
        }
        for (a in active) {
            if (a.dmId !in seen) {
                val idx = items.indexOfFirst { it.id == a.id }
                if (idx >= 0) {
                    items[idx] = items[idx].copy(state = 3)
                    changed = true
                }
            }
        }
        if (changed) save()
    }

    private fun save() {
        val arr = JSONArray()
        for (r in items) {
            val o = JSONObject()
            o.put("id", r.id)
            o.put("titleKey", r.titleKey)
            o.put("titleName", r.titleName)
            o.put("cover", r.cover ?: JSONObject.NULL)
            o.put("kindLabel", r.kindLabel)
            o.put("epId", r.epId)
            o.put("epNumber", r.epNumber ?: JSONObject.NULL)
            o.put("epName", r.epName ?: JSONObject.NULL)
            o.put("fileName", r.fileName)
            o.put("dmId", r.dmId)
            o.put("done", r.done)
            o.put("progress", r.progress.toDouble())
            o.put("bytes", r.bytes)
            o.put("state", r.state)
            arr.put(o)
        }
        Prefs.putRaw("downloads", arr.toString())
    }

    private fun load() {
        items.clear()
        val raw = Prefs.getRaw("downloads") ?: return
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(
                    DlRecord(
                        id = o.getString("id"),
                        titleKey = o.getString("titleKey"),
                        titleName = o.getString("titleName"),
                        cover = if (o.isNull("cover")) null else o.getString("cover"),
                        kindLabel = o.getString("kindLabel"),
                        epId = o.getLong("epId"),
                        epNumber = if (o.isNull("epNumber")) null else o.getInt("epNumber"),
                        epName = if (o.isNull("epName")) null else o.getString("epName"),
                        fileName = o.getString("fileName"),
                        dmId = o.getLong("dmId"),
                        done = o.getBoolean("done"),
                        progress = o.getDouble("progress").toFloat(),
                        bytes = o.getLong("bytes"),
                        state = o.getInt("state")
                    )
                )
            }
        } catch (e: Exception) {
            items.clear()
        }
    }
}
