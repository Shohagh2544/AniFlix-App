package com.shohagh.aniflixapp

object Config {
    // Supabase project (the anon key is public by design; it only has read access through your policies)
    const val SUPABASE_URL = "https://wzltxdwrcmrfxxrwqxvm.supabase.co"
    const val SUPABASE_KEY =
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind6bHR4ZHdyY21yZnh4cndxeHZtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI4MjczMTgsImV4cCI6MjEwODQwMzMxOH0.OefY2EBUDOkxNZX46QWczQy3Bw1p40WWR8igHfXgui0"

    // Embedded players (Abyss, Drive, ...) are shown inside a page that claims this address,
    // so hosts that only allow certain domains keep working.
    const val SITE = "https://shohagh2544.github.io/AniFlix/"
}
