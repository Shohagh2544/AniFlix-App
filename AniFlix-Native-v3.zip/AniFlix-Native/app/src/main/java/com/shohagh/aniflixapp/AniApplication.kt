package com.shohagh.aniflixapp

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class AniApplication : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Downloads.init(this)
        History.load()
        Repo.init(this)

        // Start loading the lists before the first screen is even drawn.
        CoroutineScope(Dispatchers.IO).launch { Repo.all() }

        // Wake up the built-in browser engine once, so the first embedded video opens faster.
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                WebView(applicationContext).destroy()
            } catch (e: Exception) {
            }
        }, 2500)
    }

    /** Big image cache: covers stay on the phone and show instantly the next time. */
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        // A browser downloads many pictures at once. OkHttp's default is only 5 per website,
        // which made covers load one handful at a time. This allows many in parallel.
        .okHttpClient {
            OkHttpClient.Builder()
                .dispatcher(Dispatcher().apply {
                    maxRequests = 64
                    maxRequestsPerHost = 32
                })
                .connectionPool(ConnectionPool(8, 5, TimeUnit.MINUTES))
                .connectTimeout(10, TimeUnit.SECONDS)
                .build()
        }
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
        .diskCache {
            DiskCache.Builder()
                .directory(cacheDir.resolve("covers"))
                .maxSizeBytes(300L * 1024 * 1024)
                .build()
        }
        .respectCacheHeaders(false)
        .crossfade(120)
        .build()
}
