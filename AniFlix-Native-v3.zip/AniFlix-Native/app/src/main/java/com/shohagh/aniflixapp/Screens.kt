package com.shohagh.aniflixapp

import android.app.Activity
import android.content.pm.ActivityInfo
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** Keeps the random banner stable while you move around the app. */
object HomeState {
    var hero by mutableStateOf<Title?>(null)
}

@Composable
fun Loader() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Red)
    }
}

/** Turns the screen sideways and hides the system bars while a video is fullscreen. */
@Composable
fun FullscreenEffect(fullscreen: Boolean) {
    val activity = LocalContext.current as? Activity
    DisposableEffect(fullscreen) {
        if (activity != null) {
            activity.requestedOrientation =
                if (fullscreen) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            setBars(activity, fullscreen)
        }
        onDispose { }
    }
    DisposableEffect(Unit) {
        onDispose {
            if (activity != null) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                setBars(activity, false)
            }
        }
    }
}

@Composable
fun TitleGrid(list: List<Title>, nav: (Route) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 110.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(list, key = { it.key }) { t ->
            Reveal(key = "grid_${t.key}") {
                Poster(t, Modifier.aspectRatio(2f / 3f)) { nav(Route.Detail(t.kind, t.id)) }
            }
        }
    }
}

// ---------------------------------------------------------------- search bar that widens

@Composable
fun SearchRow(t: Title, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().bounceClick(onClick).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = t.cover,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(width = 42.dp, height = 60.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF1E1E22))
        )
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                t.name,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                listOfNotNull(t.kind.label, t.year?.toString(), t.rating?.let { "★ ${fmtRating(it)}" }).joinToString("  ·  "),
                color = Muted,
                fontSize = 12.sp
            )
        }
    }
}

/**
 * Page title on the left and a round search button on the right. Tapping the button widens it
 * across the top (the title fades away), the page dims, and a glass list of matches drops down.
 */
@Composable
fun SearchScaffold(title: String, nav: (Route) -> Unit, content: @Composable () -> Unit) {
    var searchOpen by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var all by remember { mutableStateOf<List<Title>>(emptyList()) }
    val frac by animateFloatAsState(if (searchOpen) 1f else 0f, tween(430, easing = FastOutSlowInEasing), label = "searchWidth")
    LaunchedEffect(searchOpen) { if (searchOpen && all.isEmpty()) all = Repo.all() }
    val close = {
        searchOpen = false
        q = ""
    }
    BackHandler(enabled = searchOpen) { close() }
    val query = q.trim().lowercase()
    val suggestions = remember(all.size) { all.shuffled().take(5) }
    val rows = if (query.isEmpty()) suggestions else all.filter { it.name.lowercase().contains(query) }.take(8)

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).height(44.dp)) {
                val barWidth = 44.dp + (maxWidth - 44.dp) * frac
                Text(
                    title,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Red,
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .graphicsLayer {
                            alpha = 1f - frac
                            translationX = -40f * frac
                        }
                )
                Row(
                    Modifier
                        .align(Alignment.CenterEnd)
                        .width(barWidth)
                        .height(44.dp)
                        .glass(RoundedCornerShape(22.dp), 0.10f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(44.dp).bounceClick { if (searchOpen) close() else searchOpen = true },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                    }
                    if (frac > 0.25f) {
                        BasicTextField(
                            value = q,
                            onValueChange = { q = it },
                            singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                            cursorBrush = SolidColor(Red),
                            modifier = Modifier
                                .weight(1f)
                                .graphicsLayer { alpha = ((frac - 0.25f) / 0.75f).coerceIn(0f, 1f) },
                            decorationBox = { inner ->
                                Box(contentAlignment = Alignment.CenterStart) {
                                    if (q.isEmpty()) Text("Search anime, movies, series...", color = Muted, fontSize = 15.sp)
                                    inner()
                                }
                            }
                        )
                        Box(
                            Modifier.size(44.dp).bounceClick { close() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }
            }
            Box(Modifier.weight(1f)) { content() }
        }

        AnimatedVisibility(visible = searchOpen, enter = fadeIn(tween(250)), exit = fadeOut(tween(200))) {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(top = 68.dp)
                    .background(Color(0xCC000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { close() }
            )
        }
        AnimatedVisibility(
            visible = searchOpen,
            modifier = Modifier.padding(top = 72.dp).padding(horizontal = 16.dp),
            enter = fadeIn(tween(300)) + slideInVertically(tween(350)) { -it / 8 },
            exit = fadeOut(tween(160))
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .heightIn(max = 430.dp)
                    .glass(RoundedCornerShape(26.dp), 0.08f, Color(0xE60B0B0E))
                    .verticalScroll(rememberScrollState())
                    .padding(8.dp)
            ) {
                Text(
                    if (query.isEmpty()) "Suggestions" else if (rows.isEmpty()) "No results" else "Results",
                    color = Muted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
                rows.forEach { t ->
                    SearchRow(t) {
                        close()
                        nav(Route.Detail(t.kind, t.id))
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- home & lists

@Composable
fun HomeScreen(data: SnapshotStateMap<Kind, KindData>, listState: LazyListState, nav: (Route) -> Unit) {
    LaunchedEffect(Unit) {
        Kind.entries.forEach { k ->
            if (data[k] == null) launch { data[k] = Repo.loadKind(k) }
        }
    }
    // when fresh data from the server arrives in the background, refresh the rows quietly
    val version = Repo.updates.intValue
    LaunchedEffect(version) {
        if (version > 0) Kind.entries.forEach { k -> data[k] = Repo.loadKind(k) }
    }
    val pool = data.values.flatMap { it.items }.filter { it.cover != null }
    LaunchedEffect(pool.size) {
        if (HomeState.hero == null && pool.isNotEmpty()) HomeState.hero = pool.random()
    }
    val hero = HomeState.hero

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 4.dp, bottom = 110.dp)
    ) {
        item(key = "hero") {
            Reveal(key = "home_hero") {
                if (hero != null) {
                    Hero(
                        hero,
                        parallax = {
                            if (listState.firstVisibleItemIndex == 0) listState.firstVisibleItemScrollOffset * 0.35f else 0f
                        }
                    ) { nav(Route.Detail(hero.kind, hero.id)) }
                } else {
                    Box(
                        Modifier
                            .padding(horizontal = 16.dp)
                            .fillMaxWidth()
                            .height(440.dp)
                            .background(CardBg, RoundedCornerShape(32.dp))
                    )
                }
            }
        }
        Kind.entries.forEachIndexed { n, k ->
            val kd = data[k]
            if (kd != null && kd.items.isNotEmpty()) {
                item(key = k.name) {
                    Reveal(key = "home_${k.name}", delayMs = 60 * (n + 1)) {
                        Section(
                            k.plural,
                            kd.items,
                            { t -> nav(Route.Detail(t.kind, t.id)) },
                            { nav(Route.SeeAll(k)) }
                        )
                    }
                }
            }
        }
        val err = data[Kind.ANIME]?.error
        if (err != null) {
            item(key = "err") {
                Text(
                    "Could not load: $err\nYour downloads still work from the Downloads tab.",
                    color = Muted,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
}

@Composable
fun MyListScreen(saved: Set<String>, nav: (Route) -> Unit) {
    var all by remember { mutableStateOf<List<Title>?>(null) }
    LaunchedEffect(Unit) { all = Repo.all() }
    val loaded = all
    val items = loaded?.filter { saved.contains(it.key) } ?: emptyList()
    Column(Modifier.fillMaxSize()) {
        if (loaded == null) {
            Loader()
        } else if (items.isEmpty()) {
            Text(
                "Tap the heart on any title to save it here.",
                color = Muted,
                modifier = Modifier.padding(16.dp)
            )
        } else {
            Text("${items.size} saved", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
            TitleGrid(items, nav)
        }
    }
}

@Composable
fun SeeAllScreen(kind: Kind, back: () -> Unit, nav: (Route) -> Unit) {
    var list by remember { mutableStateOf<List<Title>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(kind) {
        val kd = Repo.loadKind(kind)
        list = kd.items
        error = kd.error
    }
    val l = list
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(kind.plural, sub = if (l == null) null else "${l.size} titles", onBack = back)
        if (l == null) {
            Loader()
        } else if (l.isEmpty()) {
            Text(
                if (error != null) "Could not load: $error" else "Nothing here yet.",
                color = Muted,
                modifier = Modifier.padding(16.dp)
            )
        } else {
            TitleGrid(l, nav)
        }
    }
}

// ---------------------------------------------------------------- downloads & history

@Composable
fun DlRow(r: DlRecord, onPlay: () -> Unit, onDelete: () -> Unit) {
    val p by animateFloatAsState(r.progress, label = "dlProgress")
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (r.done) Modifier.bounceClick(onPlay) else Modifier)
            .glass(RoundedCornerShape(20.dp), 0.08f)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = r.cover,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(width = 58.dp, height = 82.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1E1E22))
        )
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                r.titleName,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(r.label, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            if (r.done) {
                Text("Ready offline · ${fmtSize(r.bytes)}", color = Color(0xFF6FE08A), fontSize = 12.sp)
            } else {
                if (r.state != 3) {
                    LinearProgressIndicator(
                        progress = { p },
                        modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)),
                        color = Red,
                        trackColor = Color(0x33FFFFFF)
                    )
                    Spacer(Modifier.height(4.dp))
                }
                val status = when (r.state) {
                    0 -> "Waiting..."
                    2 -> "Paused"
                    3 -> "Failed. Delete it and try again."
                    else -> "Downloading ${(r.progress * 100).toInt()}%  ·  ${fmtSize(r.bytes)}"
                }
                Text(status, color = Muted, fontSize = 12.sp)
            }
        }
        if (r.done) {
            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White)
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Muted)
        }
    }
}

@Composable
fun HistoryRow(h: HistoryItem, onPlay: () -> Unit, onDelete: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .bounceClick(onPlay)
            .glass(RoundedCornerShape(20.dp), 0.08f)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = h.cover,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(width = 58.dp, height = 82.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1E1E22))
        )
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                h.titleName,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(h.label, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text("Watched " + timeAgo(h.time), color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.PlayArrow, contentDescription = "Watch again", tint = Color.White)
        IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Muted)
        }
    }
}

@Composable
fun EmptyState(title: String, text: String, showIcon: Boolean) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (showIcon) {
                Icon(DownloadIcon, contentDescription = null, tint = Muted, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(12.dp))
            }
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(text, color = Muted, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun DownloadsScreen(nav: (Route) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val list = Downloads.items
    val ready = list.filter { it.done }
    var toDelete by remember { mutableStateOf<DlRecord?>(null) }
    var askClear by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            "Downloads",
            sub = if (tab == 0) {
                if (list.isEmpty()) null else "${ready.size} ready  ·  ${fmtSize(ready.sumOf { it.bytes })}"
            } else {
                if (History.items.isEmpty()) null else "${History.items.size} watched"
            }
        )
        GlassSegment(tab, listOf("Downloads", "History")) { tab = it }
        Crossfade(targetState = tab, label = "downloadsTab") { t ->
            if (t == 0) {
                if (list.isEmpty()) {
                    EmptyState(
                        "No downloads yet",
                        "Open any anime, movie or series and tap Download. Saved videos play here without internet.",
                        true
                    )
                } else {
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 110.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(list, key = { it.id }) { r ->
                            DlRow(r, onPlay = { nav(Route.Offline(r.id)) }, onDelete = { toDelete = r })
                        }
                    }
                }
            } else {
                if (History.items.isEmpty()) {
                    EmptyState("Nothing watched yet", "Videos you watch will show up here so you can jump back in.", false)
                } else {
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 110.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item(key = "clear") {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { askClear = true }) { Text("Clear all", color = Red) }
                            }
                        }
                        items(History.items, key = { it.id }) { h ->
                            HistoryRow(
                                h,
                                onPlay = {
                                    val rec = Downloads.has(h.titleKey, h.epId)
                                    if (rec != null && rec.done) nav(Route.Offline(rec.id))
                                    else nav(Route.Watch(h.kind, h.titleId, h.epId))
                                },
                                onDelete = { History.remove(h) }
                            )
                        }
                    }
                }
            }
        }
    }

    val d = toDelete
    if (d != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = Color(0xF2101012),
            shape = RoundedCornerShape(28.dp),
            title = { Text("Delete download?", color = Color.White) },
            text = { Text("${d.titleName} · ${d.label} will be removed from this phone.", color = Muted) },
            confirmButton = {
                TextButton(onClick = {
                    Downloads.remove(d)
                    toDelete = null
                }) { Text("Delete", color = Red) }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("Cancel", color = Color.White) }
            }
        )
    }
    if (askClear) {
        AlertDialog(
            onDismissRequest = { askClear = false },
            containerColor = Color(0xF2101012),
            shape = RoundedCornerShape(28.dp),
            title = { Text("Clear history?", color = Color.White) },
            text = { Text("This removes the list of videos you watched. Your downloads stay.", color = Muted) },
            confirmButton = {
                TextButton(onClick = {
                    History.clear()
                    askClear = false
                }) { Text("Clear", color = Red) }
            },
            dismissButton = {
                TextButton(onClick = { askClear = false }) { Text("Cancel", color = Color.White) }
            }
        )
    }
}

@Composable
fun EpisodePickerDialog(
    t: Title,
    eps: List<Episode>,
    onDismiss: () -> Unit,
    onConfirm: (List<Episode>) -> Unit
) {
    val selectable = eps.filter { canDownload(it.videoUrl) && Downloads.has(t.key, it.id) == null }
    val picked = remember { mutableStateListOf<Long>() }
    val allPicked = selectable.isNotEmpty() && picked.size == selectable.size

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xF2101012),
        shape = RoundedCornerShape(28.dp),
        title = { Text("Download episodes", color = Color.White) },
        text = {
            Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable(enabled = selectable.isNotEmpty()) {
                            if (allPicked) {
                                picked.clear()
                            } else {
                                picked.clear()
                                picked.addAll(selectable.map { it.id })
                            }
                        }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = allPicked,
                        onCheckedChange = null,
                        enabled = selectable.isNotEmpty(),
                        colors = CheckboxDefaults.colors(checkedColor = Red)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Select all", color = Color.White, fontWeight = FontWeight.SemiBold)
                }
                eps.forEachIndexed { i, e ->
                    val n = e.number ?: (i + 1)
                    val existing = Downloads.has(t.key, e.id)
                    val ok = canDownload(e.videoUrl) && existing == null
                    val note = when {
                        existing != null && existing.done -> "Downloaded"
                        existing != null -> "Downloading"
                        !canDownload(e.videoUrl) -> "Not available"
                        else -> ""
                    }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable(enabled = ok) {
                                if (picked.contains(e.id)) picked.remove(e.id) else picked.add(e.id)
                            }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = picked.contains(e.id),
                            onCheckedChange = null,
                            enabled = ok,
                            colors = CheckboxDefaults.colors(checkedColor = Red)
                        )
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Episode $n" + (if (e.name != null) " · ${e.name}" else ""),
                                color = if (ok) Color.White else Muted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (note.isNotEmpty()) Text(note, color = Muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(selectable.filter { picked.contains(it.id) }) },
                enabled = picked.isNotEmpty()
            ) { Text("Download (${picked.size})", color = if (picked.isNotEmpty()) Red else Muted) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White) }
        }
    )
}

// ---------------------------------------------------------------- detail

@Composable
fun DetailScreen(
    kind: Kind,
    id: Long,
    saved: Set<String>,
    onToggle: (String) -> Unit,
    back: () -> Unit,
    nav: (Route) -> Unit
) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf<Title?>(null) }
    var eps by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    val scroll = rememberScrollState()

    LaunchedEffect(kind, id) {
        try {
            val t = Repo.find(kind, id)
            title = t
            if (t != null) eps = Repo.episodes(t)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = e.message ?: "error"
        }
    }

    val t = title
    if (t == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            if (error != null) Text("Could not load: $error", color = Muted) else CircularProgressIndicator(color = Red)
        }
        return
    }

    val lastId = Prefs.lastEp(t.key)
    val startEp = eps.firstOrNull { it.id == lastId } ?: eps.firstOrNull()
    val isSaved = saved.contains(t.key)
    val label = when {
        kind == Kind.MOVIE -> "Play Movie"
        startEp != null && startEp.id == lastId -> "Continue Watching"
        else -> "Start Watching"
    }

    // download button state
    val movieRec = if (kind == Kind.MOVIE) Downloads.has(t.key, 0L) else null
    val anyDownloadable = if (kind == Kind.MOVIE) canDownload(t.videoUrl) else eps.any { canDownload(it.videoUrl) }
    val epRecs = if (kind == Kind.MOVIE) emptyList() else eps.mapNotNull { Downloads.has(t.key, it.id) }
    val dlLabel = when {
        kind == Kind.MOVIE && movieRec != null && movieRec.done -> "Downloaded · Play offline"
        kind == Kind.MOVIE && movieRec != null -> "Downloading ${(movieRec.progress * 100).toInt()}%"
        kind != Kind.MOVIE && epRecs.isNotEmpty() -> "Downloads (${epRecs.count { it.done }}/${eps.size})"
        !anyDownloadable -> "Download not available"
        else -> "Download"
    }

    Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
        Box(Modifier.fillMaxWidth().height(380.dp).clipToBounds()) {
            AsyncImage(
                model = t.cover,
                contentDescription = t.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        translationY = minOf(scroll.value * 0.25f, size.height * 0.08f)
                        scaleX = 1.2f
                        scaleY = 1.2f
                    }
            )
            Box(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.55f)
                    .align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
            )
            Box(Modifier.align(Alignment.TopStart).padding(12.dp)) {
                RoundIcon(back) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
            }
            Box(Modifier.align(Alignment.TopEnd).padding(12.dp)) {
                RoundIcon({ onToggle(t.key) }) {
                    Icon(
                        if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "My List",
                        tint = if (isSaved) Red else Color.White
                    )
                }
            }
        }
        Column(Modifier.padding(horizontal = 16.dp)) {
            Reveal(key = "detail_${t.key}_head") {
                Column {
                    Text(t.name, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Chip(kind.label)
                        t.year?.let { Chip(it.toString()) }
                        t.rating?.let { Chip("★ ${fmtRating(it)}") }
                    }
                    t.genre?.let { Text(it, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
                }
            }
            Spacer(Modifier.height(16.dp))

            Reveal(key = "detail_${t.key}_buttons", delayMs = 80) {
                Column {
                    if (kind == Kind.MOVIE) {
                        if (t.videoUrl != null) {
                            RedButton(label, Modifier.fillMaxWidth()) { nav(Route.Watch(kind, id, 0L)) }
                        } else {
                            Text("No video yet.", color = Muted)
                        }
                    } else if (startEp != null) {
                        RedButton(label, Modifier.fillMaxWidth()) { nav(Route.Watch(kind, id, startEp.id)) }
                    } else {
                        Text("No episodes yet.", color = Muted)
                    }
                    Spacer(Modifier.height(10.dp))
                    DownloadButton(
                        dlLabel,
                        enabled = anyDownloadable || movieRec != null || epRecs.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (kind == Kind.MOVIE) {
                            if (movieRec == null) {
                                val n = Downloads.enqueue(t, null)
                                Toast.makeText(
                                    ctx,
                                    if (n > 0) "Download started" else "Could not start the download",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else if (movieRec.done) {
                                nav(Route.Offline(movieRec.id))
                            } else {
                                nav(Route.Downloads)
                            }
                        } else {
                            showPicker = true
                        }
                    }
                    if (!anyDownloadable && movieRec == null && epRecs.isEmpty()) {
                        Text(
                            "This video plays in an embedded player, so it can't be saved offline.",
                            color = Muted,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 6.dp, start = 4.dp)
                        )
                    }
                }
            }

            if (t.description.isNotBlank()) {
                Spacer(Modifier.height(16.dp))
                Text(
                    t.description,
                    color = Muted,
                    fontSize = 14.5.sp,
                    maxLines = if (expanded) Int.MAX_VALUE else 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.animateContentSize().clickable { expanded = !expanded }
                )
            }

            if (kind != Kind.MOVIE && eps.isNotEmpty()) {
                Spacer(Modifier.height(22.dp))
                Text("Episodes", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    eps.forEachIndexed { i, e ->
                        Reveal(key = "ep_${t.key}_${e.id}", delayMs = minOf(i, 8) * 50) {
                            EpisodeRow(e, i, e.id == lastId) { nav(Route.Watch(kind, id, e.id)) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }

    if (showPicker) {
        EpisodePickerDialog(
            t = t,
            eps = eps,
            onDismiss = { showPicker = false },
            onConfirm = { chosen ->
                showPicker = false
                val n = Downloads.enqueue(t, chosen)
                Toast.makeText(
                    ctx,
                    if (n > 0) "$n added to Downloads" else "Could not start the download",
                    Toast.LENGTH_SHORT
                ).show()
            }
        )
    }
}

// ---------------------------------------------------------------- watch (online)

@Composable
fun WatchScreen(kind: Kind, id: Long, epId: Long, back: () -> Unit, nav: (Route) -> Unit) {
    var title by remember { mutableStateOf<Title?>(null) }
    var eps by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var failed by remember { mutableStateOf<String?>(null) }
    var sugg by remember { mutableStateOf<List<Title>>(emptyList()) }
    var curId by remember(kind, id, epId) { mutableStateOf(epId) }
    var fullscreen by remember { mutableStateOf(false) }

    LaunchedEffect(kind, id) {
        try {
            val t = Repo.find(kind, id)
            title = t
            eps = if (t != null) Repo.episodes(t) else emptyList()
            sugg = Repo.all().filter { !(it.kind == kind && it.id == id) }.shuffled().take(6)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            failed = e.message ?: "error"
        }
    }

    val t = title
    val idx = eps.indexOfFirst { it.id == curId }
    val ep = eps.getOrNull(idx)
    val url: String? = if (kind == Kind.MOVIE) t?.videoUrl else ep?.videoUrl
    val multi = kind != Kind.MOVIE && eps.size > 1

    LaunchedEffect(t?.key, ep?.id) {
        if (t != null && ep != null) Prefs.setLastEp(t.key, ep.id)
        if (t != null && (kind == Kind.MOVIE || ep != null)) History.add(t, ep)
    }

    FullscreenEffect(fullscreen)
    BackHandler(enabled = fullscreen) { fullscreen = false }

    Column(Modifier.fillMaxSize()) {
        if (!fullscreen) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIcon(back) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        t?.name ?: "",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    val sub = if (kind == Kind.MOVIE) "Movie" else if (ep != null) "Episode ${ep.number ?: (idx + 1)}" else ""
                    Text(sub, fontSize = 13.sp, color = Muted)
                }
            }
        }

        Box(
            (if (fullscreen) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                .background(Color.Black)
        ) {
            if (failed != null) {
                Text("Could not load: $failed", color = Muted, modifier = Modifier.align(Alignment.Center))
            } else if (url == null) {
                Text(
                    if (t == null) "Loading..." else "No video yet.",
                    color = Muted,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (isDirect(url)) {
                key(url) {
                    ExoView(
                        url,
                        onEnded = { if (multi) eps.getOrNull(idx + 1)?.let { curId = it.id } },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Text(
                    "⛶",
                    color = Color.White,
                    fontSize = 24.sp,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .clickable { fullscreen = !fullscreen }
                )
            } else {
                key(url) { EmbedView(url, Modifier.fillMaxSize()) }
            }
        }

        if (!fullscreen) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
                if (multi) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { eps.getOrNull(idx - 1)?.let { curId = it.id } },
                            enabled = idx > 0
                        ) { Text("‹ Prev") }
                        Text(
                            ep?.name ?: "",
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = { eps.getOrNull(idx + 1)?.let { curId = it.id } },
                            enabled = idx < eps.lastIndex
                        ) { Text("Next ›") }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("Episodes", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        eps.forEachIndexed { i, e -> EpisodeRow(e, i, e.id == curId) { curId = e.id } }
                    }
                } else if (t != null && t.description.isNotBlank()) {
                    Text(t.description, color = Muted, fontSize = 14.5.sp)
                }
                if (sugg.isNotEmpty()) {
                    Spacer(Modifier.height(24.dp))
                    Text("You may also like", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(10.dp))
                    SuggestGrid(sugg) { s -> nav(Route.Detail(s.kind, s.id)) }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

// ---------------------------------------------------------------- watch (offline)

@Composable
fun OfflineScreen(recId: String, back: () -> Unit) {
    var curId by remember(recId) { mutableStateOf(recId) }
    var fullscreen by remember { mutableStateOf(false) }
    val rec0 = Downloads.items.firstOrNull { it.id == recId }
    val group = Downloads.items
        .filter { it.titleKey == rec0?.titleKey && it.done }
        .sortedBy { it.epNumber ?: 0 }
    val rec = group.firstOrNull { it.id == curId } ?: rec0
    val idx = group.indexOfFirst { it.id == rec?.id }
    val src = if (rec != null) Downloads.uri(rec) else null

    LaunchedEffect(rec?.id) {
        if (rec != null) History.addDownload(rec)
    }

    FullscreenEffect(fullscreen)
    BackHandler(enabled = fullscreen) { fullscreen = false }

    Column(Modifier.fillMaxSize()) {
        if (!fullscreen) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIcon(back) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        rec?.titleName ?: "",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text("${rec?.label ?: ""}  ·  Offline", fontSize = 13.sp, color = Muted)
                }
            }
        }

        Box(
            (if (fullscreen) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                .background(Color.Black)
        ) {
            if (src == null) {
                Text("This file is no longer on the phone.", color = Muted, modifier = Modifier.align(Alignment.Center))
            } else {
                key(src) {
                    ExoView(
                        src,
                        onEnded = { group.getOrNull(idx + 1)?.let { curId = it.id } },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Text(
                    "⛶",
                    color = Color.White,
                    fontSize = 24.sp,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .clickable { fullscreen = !fullscreen }
                )
            }
        }

        if (!fullscreen && group.size > 1) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
                Text("Downloaded episodes", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    group.forEachIndexed { i, r ->
                        EpisodeRow(Episode(r.epId, r.epNumber, r.epName, null), i, r.id == rec?.id) { curId = r.id }
                    }
                }
            }
        }
    }
}
