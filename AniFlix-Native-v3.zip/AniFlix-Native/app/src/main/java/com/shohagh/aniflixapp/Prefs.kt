package com.shohagh.aniflixapp

import android.content.Context
import android.content.SharedPreferences

/** Small on-device storage: My List and the last episode watched per title. */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("aniflix", Context.MODE_PRIVATE)
    }

    fun saved(): Set<String> = (sp.getStringSet("list", emptySet()) ?: emptySet()).toSet()

    /** Adds or removes the title key. Returns true if it is now saved. */
    fun toggle(key: String): Boolean {
        val s = saved().toMutableSet()
        val added = if (s.contains(key)) {
            s.remove(key)
            false
        } else {
            s.add(key)
            true
        }
        sp.edit().putStringSet("list", s).apply()
        return added
    }

    fun lastEp(key: String): Long = sp.getLong("last:$key", -1L)

    fun setLastEp(key: String, episodeId: Long) {
        sp.edit().putLong("last:$key", episodeId).apply()
    }

    fun getRaw(key: String): String? = sp.getString(key, null)

    fun putRaw(key: String, value: String) {
        sp.edit().putString(key, value).apply()
    }
}
