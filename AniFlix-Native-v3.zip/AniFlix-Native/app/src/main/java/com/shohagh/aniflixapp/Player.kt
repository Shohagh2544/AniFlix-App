package com.shohagh.aniflixapp

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

/**
 * Fullscreen video mode: hides the status/navigation bars and lets the picture use the whole screen,
 * including the area behind a notch or camera hole. Turning it off restores the normal layout.
 */
fun setBars(act: Activity, hide: Boolean) {
    val w = act.window
    if (Build.VERSION.SDK_INT >= 28) {
        val lp = w.attributes
        lp.layoutInDisplayCutoutMode = if (hide) {
            if (Build.VERSION.SDK_INT >= 30) {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        } else {
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        }
        w.attributes = lp
    }
    WindowCompat.setDecorFitsSystemWindows(w, !hide)
    val c = WindowCompat.getInsetsController(w, w.decorView)
    if (hide) {
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    } else {
        c.show(WindowInsetsCompat.Type.systemBars())
    }
}

/**
 * Native player for direct video links (.mp4, .m3u8, ...) and for downloaded files.
 * Starts playing after about one second of video is buffered instead of waiting longer.
 */
@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun ExoView(url: String, onEnded: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var buffering by remember(url) { mutableStateOf(true) }
    val player = remember(url) {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(15_000)
            .setDefaultRequestProperties(mapOf("Referer" to Config.SITE))
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 120_000, 1_000, 3_000)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        ExoPlayer.Builder(ctx, DefaultRenderersFactory(ctx).setEnableDecoderFallback(true))
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, http)))
            .setLoadControl(load)
            .build()
            .apply {
                setMediaItem(MediaItem.fromUri(url))
                prepare()
                playWhenReady = true
            }
    }
    val ended by rememberUpdatedState(onEnded)
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                buffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_ENDED) ended()
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }
    Box(modifier) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    this.player = player
                    useController = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        if (buffering) {
            CircularProgressIndicator(color = Red, modifier = Modifier.align(Alignment.Center))
        }
    }
}

/**
 * Player for embedded pages (Abyss, Drive, Vidmoly, ...).
 * The embed is shown inside an iframe on a page that claims your website address,
 * so hosts with an "allowed domains" list keep working. Pop-ups and redirects are blocked.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun EmbedView(url: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    var showing by remember { mutableStateOf(false) }
    var loading by remember(url) { mutableStateOf(true) }
    val chromeRef = remember { arrayOfNulls<WebChromeClient>(1) }
    val webRef = remember { arrayOfNulls<WebView>(1) }

    BackHandler(enabled = showing) { chromeRef[0]?.onHideCustomView() }

    // never leave the spinner up forever (some ad scripts keep the page "loading")
    LaunchedEffect(url) {
        delay(6000)
        loading = false
    }

    DisposableEffect(Unit) {
        onDispose {
            chromeRef[0]?.onHideCustomView()
            webRef[0]?.destroy()
            webRef[0] = null
        }
    }

    Box(modifier.background(Color.Black)) {
        AndroidView(
            factory = { c ->
                WebView(c).apply {
                    webRef[0] = this
                    setLayerType(View.LAYER_TYPE_HARDWARE, null)
                    setBackgroundColor(android.graphics.Color.BLACK)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.setSupportMultipleWindows(false)
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.setSupportZoom(false)
                    settings.userAgentString = settings.userAgentString.replace("; wv", "")
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                    webViewClient = object : WebViewClient() {
                        // Block any attempt to navigate away from the player page (ad redirects).
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                            request.isForMainFrame

                        override fun onPageFinished(view: WebView?, url: String?) {
                            loading = false
                        }
                    }

                    val chrome = object : WebChromeClient() {
                        private var custom: View? = null
                        private var callback: CustomViewCallback? = null

                        override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                            val a = activity
                            if (custom != null || a == null) {
                                cb.onCustomViewHidden()
                                return
                            }
                            custom = view
                            callback = cb
                            (a.window.decorView as ViewGroup).addView(
                                view,
                                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                            )
                            a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            setBars(a, true)
                            showing = true
                        }

                        override fun onHideCustomView() {
                            val v = custom ?: return
                            val a = activity
                            if (a != null) {
                                (a.window.decorView as ViewGroup).removeView(v)
                                a.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                setBars(a, false)
                            }
                            custom = null
                            callback?.onCustomViewHidden()
                            callback = null
                            showing = false
                        }
                    }
                    chromeRef[0] = chrome
                    webChromeClient = chrome

                    val page = "<html><body style=\"margin:0;background:#000\">" +
                        "<iframe src=\"" + url.replace("\"", "%22") + "\" " +
                        "style=\"position:fixed;top:0;left:0;width:100%;height:100%;border:0\" " +
                        "allowfullscreen allow=\"autoplay; fullscreen; encrypted-media\"></iframe></body></html>"
                    loadDataWithBaseURL(Config.SITE, page, "text/html", "utf-8", null)
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        if (loading) {
            Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Red)
            }
        }
    }
}
