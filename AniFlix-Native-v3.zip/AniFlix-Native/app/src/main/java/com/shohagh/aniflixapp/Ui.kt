package com.shohagh.aniflixapp

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import java.util.Locale

val Red = Color(0xFFE50914)
val RedLight = Color(0xFFFF3B47)
val RedDark = Color(0xFFC1121F)
val Muted = Color(0xFFB4B4BC)
val CardBg = Color(0xFF141416)

@Composable
fun AniTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red,
            onPrimary = Color.White,
            background = Color.Black,
            onBackground = Color.White,
            surface = Color(0xFF0E0E10),
            onSurface = Color.White,
            surfaceVariant = CardBg,
            onSurfaceVariant = Muted
        ),
        content = content
    )
}

fun fmtRating(r: Double): String = String.format(Locale.US, "%.1f", r)

private val directRegex = Regex("""\.(mp4|webm|m4v|mkv|m3u8)(\?|$)""", RegexOption.IGNORE_CASE)

/** True for links that point straight at a video file (played by the native player). */
fun isDirect(url: String): Boolean = directRegex.containsMatchIn(url)

/** Download arrow icon (the core icon set has none). */
val DownloadIcon: ImageVector by lazy {
    ImageVector.Builder(
        name = "Download",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f
    ).apply {
        path(fill = SolidColor(Color.Black)) {
            moveTo(19f, 9f)
            horizontalLineToRelative(-4f)
            verticalLineTo(3f)
            horizontalLineTo(9f)
            verticalLineToRelative(6f)
            horizontalLineTo(5f)
            lineToRelative(7f, 7f)
            lineToRelative(7f, -7f)
            close()
            moveTo(5f, 18f)
            verticalLineToRelative(2f)
            horizontalLineToRelative(14f)
            verticalLineToRelative(-2f)
            horizontalLineTo(5f)
            close()
        }
    }.build()
}

// ------------------------------------------------------------------ glass look

/**
 * "Liquid glass" panel: a dark translucent body, a soft white tint, a bright highlight in the
 * top-left corner and a thin shiny edge. (Android cannot blur what is behind a panel without an
 * extra library, so the glass is drawn with layers instead.)
 */
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(24.dp),
    tint: Float = 0.10f,
    base: Color = Color(0xB30B0B0E)
): Modifier = this
    .clip(shape)
    .background(base)
    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = tint + 0.10f), Color.White.copy(alpha = tint * 0.25f))))
    .drawBehind {
        drawRect(
            Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.20f), Color.Transparent),
                center = Offset(size.width * 0.12f, 0f),
                radius = size.maxDimension * 0.9f
            )
        )
    }
    .border(
        1.dp,
        Brush.linearGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.22f))),
        shape
    )

/** Black page with a faint red glow, so the glass panels have something to shine on. */
@Composable
fun AppBackground(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(Color(0x40E50914), Color.Transparent),
                        center = Offset(0f, 0f),
                        radius = size.maxDimension * 0.75f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(Color(0x30FF2D55), Color.Transparent),
                        center = Offset(size.width, size.height * 0.85f),
                        radius = size.maxDimension * 0.6f
                    )
                )
            }
    ) { content() }
}

// ------------------------------------------------------------------ animations

/** Click with a small springy "press" squash, like the buttons on the website. */
fun Modifier.bounceClick(onClick: () -> Unit): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(interactionSource = source, indication = null, onClick = onClick)
}

/** Titles that have already slid in once, so they do not replay when you scroll back. */
object RevealMemory {
    val seen = HashSet<String>()
}

/** Fades and slides its content up the first time it scrolls into view (like the website). */
@Composable
fun Reveal(key: String? = null, delayMs: Int = 0, content: @Composable () -> Unit) {
    val already = key != null && RevealMemory.seen.contains(key)
    var shown by remember { mutableStateOf(already) }
    LaunchedEffect(Unit) {
        if (!shown) {
            delay(delayMs.toLong())
            shown = true
            if (key != null) RevealMemory.seen.add(key)
        }
    }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(280), label = "revealA")
    val y by animateFloatAsState(if (shown) 0f else 36f, tween(320), label = "revealY")
    Box(
        Modifier.graphicsLayer {
            alpha = a
            translationY = y
        }
    ) { content() }
}

// ------------------------------------------------------------------ floating dock

class DockTab(val label: String, val icon: ImageVector)

/** Floating glass dock with a red pill that springs from tab to tab. */
@Composable
fun GlassDock(selected: Int, tabs: List<DockTab>, onTab: (Int) -> Unit) {
    val shape = RoundedCornerShape(34.dp)
    BoxWithConstraints(
        Modifier
            .padding(horizontal = 18.dp, vertical = 14.dp)
            .widthIn(max = 420.dp)
            .fillMaxWidth()
            .height(68.dp)
            .shadow(16.dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
            .glass(shape, 0.10f, Color(0xCC0A0A0D))
            .padding(6.dp)
    ) {
        val itemW = maxWidth / tabs.size
        val x by animateDpAsState(
            targetValue = itemW * selected,
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
            label = "dockPill"
        )
        Box(
            Modifier
                .offset(x = x)
                .width(itemW)
                .fillMaxHeight()
                .shadow(10.dp, RoundedCornerShape(28.dp), ambientColor = Red, spotColor = Red)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(RedLight, RedDark)))
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f), Color.Transparent), endY = 90f))
        )
        Row(Modifier.fillMaxSize()) {
            tabs.forEachIndexed { i, tab ->
                val on = i == selected
                val iconScale by animateFloatAsState(
                    if (on) 1.15f else 1f,
                    spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                    label = "dockIcon"
                )
                Column(
                    Modifier.weight(1f).fillMaxHeight().bounceClick { onTab(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        tab.icon,
                        contentDescription = tab.label,
                        tint = if (on) Color.White else Muted,
                        modifier = Modifier.graphicsLayer {
                            scaleX = iconScale
                            scaleY = iconScale
                        }
                    )
                    Text(
                        tab.label,
                        color = if (on) Color.White else Muted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ components

@Composable
fun RoundIcon(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .bounceClick(onClick)
            .glass(CircleShape, 0.10f, Color(0x80000000)),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun Chip(text: String) {
    Text(
        text,
        color = Color.White,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .glass(RoundedCornerShape(50), 0.08f, Color(0x66000000))
            .padding(horizontal = 11.dp, vertical = 5.dp)
    )
}

@Composable
fun RedButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .height(52.dp)
            .bounceClick(onClick)
            .shadow(14.dp, shape, ambientColor = Red, spotColor = Red)
            .clip(shape)
            .background(Brush.linearGradient(listOf(RedLight, RedDark)))
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.28f), Color.Transparent), endY = 70f))
            .border(
                1.dp,
                Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.05f))),
                shape
            )
            .padding(horizontal = 24.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
        Spacer(Modifier.width(6.dp))
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun DownloadButton(label: String, enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .height(52.dp)
            .then(if (enabled) Modifier.bounceClick(onClick) else Modifier)
            .glass(shape, if (enabled) 0.10f else 0.04f)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(DownloadIcon, contentDescription = null, tint = if (enabled) Color.White else Muted)
        Spacer(Modifier.width(8.dp))
        Text(label, color = if (enabled) Color.White else Muted, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
fun Poster(t: Title, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .bounceClick(onClick)
            .clip(RoundedCornerShape(20.dp))
            .background(CardBg)
    ) {
        AsyncImage(
            model = t.cover,
            contentDescription = t.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.55f)
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF2000000))))
        )
        val rating = t.rating
        if (rating != null) {
            Text(
                "★ ${fmtRating(rating)}",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .glass(RoundedCornerShape(50), 0.08f, Color(0x80000000))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(8.dp)
                .fillMaxWidth()
                .glass(RoundedCornerShape(14.dp), 0.06f, Color(0x66000000))
        ) {
            Text(
                t.name,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
fun ViewAllTile(onClick: () -> Unit) {
    Box(
        Modifier
            .width(92.dp)
            .height(198.dp)
            .bounceClick(onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(56.dp).glass(CircleShape, 0.10f, Color(0x80000000)),
                contentAlignment = Alignment.Center
            ) { Text("›", color = Color.White, fontSize = 30.sp) }
            Spacer(Modifier.height(8.dp))
            Text("View all", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun Section(title: String, list: List<Title>, onItem: (Title) -> Unit, onAll: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onAll).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("  ›", fontSize = 22.sp, color = Muted)
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(list.take(8), key = { it.key }) { t ->
                Poster(t, Modifier.width(132.dp).height(198.dp)) { onItem(t) }
            }
            item { ViewAllTile(onAll) }
        }
    }
}

/** The big banner on Home. [parallax] moves the picture slower than the page while you scroll. */
@Composable
fun Hero(t: Title, parallax: () -> Float, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .height(440.dp)
            .bounceClick(onClick)
            .clip(RoundedCornerShape(32.dp))
            .background(CardBg)
    ) {
        AsyncImage(
            model = t.cover,
            contentDescription = t.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = parallax()
                    scaleX = 1.15f
                    scaleY = 1.15f
                }
        )
        Box(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.7f)
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xF2000000))))
        )
        Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip(t.kind.label)
                t.rating?.let { Chip("★ ${fmtRating(it)}") }
                t.year?.let { Chip(it.toString()) }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                t.name,
                fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (t.description.isNotBlank()) {
                Text(t.description, color = Muted, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(14.dp))
            RedButton("Watch now", onClick = onClick)
        }
    }
}

@Composable
fun EpisodeRow(e: Episode, index: Int, active: Boolean, onClick: () -> Unit) {
    val n = e.number ?: (index + 1)
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .bounceClick(onClick)
            .glass(shape, 0.08f, if (active) Color(0xCC2A1215) else Color(0xB30B0B0E))
            .then(if (active) Modifier.border(1.5.dp, Red, shape) else Modifier)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(RedLight, RedDark))),
            contentAlignment = Alignment.Center
        ) { Text("$n", color = Color.White, fontWeight = FontWeight.Bold) }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                e.name ?: "Episode $n",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(if (active) "Now playing" else "Episode $n", color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Muted)
    }
}

@Composable
fun SuggestGrid(list: List<Title>, onItem: (Title) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { t ->
                    Poster(t, Modifier.weight(1f).aspectRatio(2f / 3f)) { onItem(t) }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun ScreenHeader(title: String, sub: String? = null, onBack: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            RoundIcon(onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(Modifier.width(12.dp))
        }
        Column {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            if (sub != null) Text(sub, fontSize = 13.sp, color = Muted)
        }
    }
}

/** Two or more options in a glass pill with a red highlight that springs to the chosen one. */
@Composable
fun GlassSegment(selected: Int, labels: List<String>, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(50)
    BoxWithConstraints(
        Modifier
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .fillMaxWidth()
            .height(46.dp)
            .glass(shape, 0.08f)
            .padding(4.dp)
    ) {
        val w = maxWidth / labels.size
        val x by animateDpAsState(
            targetValue = w * selected,
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
            label = "segment"
        )
        Box(
            Modifier
                .offset(x = x)
                .width(w)
                .fillMaxHeight()
                .clip(shape)
                .background(Brush.linearGradient(listOf(RedLight, RedDark)))
        )
        Row(Modifier.fillMaxSize()) {
            labels.forEachIndexed { i, l ->
                Box(
                    Modifier.weight(1f).fillMaxHeight().bounceClick { onSelect(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        l,
                        color = if (i == selected) Color.White else Muted,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
